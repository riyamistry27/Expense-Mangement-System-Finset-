<?php

require 'vendor/autoload.php';

$client = new Google_Client();

$client->setClientId("266468104378-gahdbnhtuucr6r93s7ved8duolj8i1ns.apps.googleusercontent.com");
$client->setClientSecret("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");
$client->setRedirectUri("http://localhost/expense-management/google-callback.php");

$client->addScope("email");
$client->addScope("profile");

$login_url = $client->createAuthUrl();

header("Location: ".$login_url);
exit();